"""
task_manager.py

This module defines the TaskManager class, which handles the management
of tasks, including adding, viewing, editing, deleting, saving, and loading
tasks from a file.

Classes:
    - TaskManager: Manages a list of tasks and performs operations such as
      adding, editing, deleting, saving, and loading tasks from a specified
      file.

Usage:
    To use the TaskManager:
    manager = TaskManager()
    manager.add_task(Task("Task Name", "Task Description", "YYYY-MM-DD"))
    manager.view_tasks()

Notes:
    Tasks are saved to and loaded from the specified file path. Ensure that
    the file path is correctly set to avoid errors when saving or loading tasks.
"""


import os
from task import Task

class TaskManager:
    def __init__(self):
        self.tasks = []
        self.file_path = os.path.join(os.path.dirname(__file__), "task_details.txt")
        self.load_tasks()

    def add_task(self, task):
        self.tasks.append(task)
        self.save_tasks()

    def view_tasks(self):
        if not self.tasks:
            print("No tasks available.")
            return

        for idx, task in enumerate(self.tasks, start=1):
            print(f"\nTask {idx}:")
            print(task)
            print("-" * 20)

    def edit_task(self, task_index, new_task):
        if 0 <= task_index < len(self.tasks):
            self.tasks[task_index] = new_task
            self.save_tasks()
        else:
            print("Invalid task index.")

    def delete_task(self, task_index):
        if 0 <= task_index < len(self.tasks):
            del self.tasks[task_index]
            self.save_tasks()
        else:
            print("Invalid task index.")

    def save_tasks(self):
        with open(self.file_path, "w") as file:
            for task in self.tasks:
                status = "Completed" if task.completed else "Not Completed"
                file.write("---------------------------\n")
                file.write(f"Task Name: {task.name}\n")
                file.write(f"Description: {task.description}\n")
                file.write(f"Due Date: {task.due_date}\n")
                file.write(f"Priority: {task.priority}\n")
                file.write(f"Status: {status}\n")
                file.write("---------------------------\n")

    def load_tasks(self):
        if os.path.exists(self.file_path):
            with open(self.file_path, "r") as file:
                task_data = {}
                for line in file:
                    line = line.strip()
                    if line.startswith("Task Name:"):
                        task_data['name'] = line.split(": ")[1]
                    elif line.startswith("Description:"):
                        task_data['description'] = line.split(": ")[1]
                    elif line.startswith("Due Date:"):
                        task_data['due_date'] = line.split(": ")[1]
                    elif line.startswith("Priority:"):
                        task_data['priority'] = line.split(": ")[1]
                    elif line.startswith("Status:"):
                        task_data['status'] = line.split(": ")[1]
                        completed = True if task_data['status'] == "Completed" else False
                        task = Task(task_data['name'], task_data['description'], task_data['due_date'],
                                    task_data['priority'], completed)
                        self.tasks.append(task)
                        task_data = {}
    def mark_task_as_completed(self, task_index):
        if 0 <= task_index < len(self.tasks):
            self.tasks[task_index].completed = True
            self.save_tasks()
        else:
            print("Invalid task index.")