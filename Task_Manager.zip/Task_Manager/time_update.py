"""
time_update.py

This module contains functionality to display a greeting message
based on the current time and user input.

Functionality:
    - Prompt the user for their name.
    - Fetch the current time.
    - Display a personalized greeting message based on the time of day.

Usage:
    To use this module, call the `display_greeting()` function.
    It will prompt the user for their name and greet them based on the current time.

Example:
    >>> display_greeting()
    Enter your name please: Alice
    14:30:15
    Hello Good Afternoon Alice
"""
import time
def display_greeting():
    #fetching name of the user
    name = input("Enter your name please: ")

    #Fetching the time from time module.
    timestamp = time.strftime('%H:%M:%S')
    print("Current Time:", timestamp)

    # Convert hour to an integer for comparison
    hour = int(time.strftime('%H'))

    # Displaying the message based on the time
    if hour < 12:
        print(f"Hello {name}, Good Morning!")
    elif 12 <= hour < 16:
        print(f"Hello {name}, Good Afternoon!")
    else:
        print(f"Hello {name}, Good Evening!")
