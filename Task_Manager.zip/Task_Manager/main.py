"""
main.py

This module serves as the entry point for the Task Manager application.
It initializes the task manager, displays a greeting message based on the
current time, and provides a menu interface for the user to manage tasks.

Usage:
    To run the Task Manager application, execute this script. The user will
    be presented with a menu to add, view, edit, or delete tasks.

Imported Modules:
    - TaskManager: Provides functionality to manage tasks, including adding,
      viewing, editing, and deleting tasks.
    - display_greeting: Displays a greeting message based on the current time.

Example:
    $ python main.py
"""
import os
from task import Task
from task_manager import TaskManager  # Importing TaskManager from task_manager.py
from time_update import display_greeting  # Importing time update functionality from time_update.py
if __name__ == "__main__":
    display_greeting()
    manager = TaskManager()
    while True:
        print("\nTask Manager Menu:")
        print("1. Add Task")
        print("2. View Tasks")
        print("3. Edit Task")
        print("4. Delete Task")
        print("5. Mark as complete")
        print("7. Save and Exit")
        action = input("Choose option: ")

        if action == '1':
            name = input("Enter task name: ")
            description = input("Enter task description: ")
            due_date = input("Enter due date (DD-MM-YYYY): ")
            priority = input("Enter task priority: ")
            new_task = Task(name, description, due_date, priority)
            manager.add_task(new_task)
            print("Task added successfully!")

        elif action == '2':
            print("\nYour tasks:")
            manager.view_tasks()

        elif action == '3':
            task_index = int(input("Enter the task index to edit: ")) - 1
            name = input("Enter new task name: ")
            description = input("Enter new task description: ")
            due_date = input("Enter new due date (YYYY-MM-DD): ")
            priority = input("Enter new task priority: ")
            edited_task = Task(name, description, due_date, priority)
            manager.edit_task(task_index, edited_task)
            print("Task edited successfully!")

        elif action == '4':
            task_index = int(input("Enter the task index to delete: ")) - 1
            manager.delete_task(task_index)
            print("Task deleted successfully!")

        elif action == '5':
            task_index = int(input("Enter the task index to mark as complete: ")) - 1
            manager.mark_task_as_completed(task_index)
            print("Task marked successfully!")

        elif action == '7':
            manager.save_tasks()
            print("Tasks saved successfully. Exiting Task Manager. Goodbye!")
            break

        else:
            print("Invalid option, please try again.")