
"""
task.py

This module defines the Task class, which represents a task with a name,
description, and due date.

Classes:
    - Task: Represents a task with a name, description, and due date.

Usage:
    To create a new task:
    task = Task("Task Name", "Task Description", "YYYY-MM-DD")

Notes:
    Ensure due_date is in 'YYYY-MM-DD' format.
"""

import os
class Task:
    def __init__(self, name, description, due_date, priority, completed=False):
        self.name = name
        self.description = description
        self.due_date = due_date
        self.priority = priority
        self.completed = completed


    def __str__(self):
        status = "Completed" if self.completed else "Not Completed"
        return f"Task: {self.name}\nDescription: {self.description}\nDue Date: {self.due_date} \n priority: {self.priority} \n Status: {self.completed}"
